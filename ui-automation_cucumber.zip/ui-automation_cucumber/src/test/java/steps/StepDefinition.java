package steps;

//import java.time.Duration;

import org.openqa.selenium.By;
//import org.openqa.selenium.chrome.ChromeDriver;

//import io.cucumber.java.en.And;
//import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
//import io.github.bonigarcia.wdm.WebDriverManager;

public class StepDefinition extends BaseClass {
	
	
	@When("Click on {string} link")
	public void clickLink(String linktext) 
	{
		driver.findElement(By.xpath("//a[contains(text(),'"+linktext+"')]")).click();
	}
	
	@Then("{string} Page should be displayed")
	public void verifyPage(String pageName)
	{
		System.out.println(pageName+" is displayed");
	}
	
	@Then("error message should be displayed")
	public void error_message_should_be_displayed() {
	    System.out.println("Error Page should be displayed");
	}
	
}
